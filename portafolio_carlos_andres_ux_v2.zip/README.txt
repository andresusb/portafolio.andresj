Portafolio UX (Dark Mode) - listo para GitHub / Render

Contenido:
- index.html
- style.css
- script.js
- assets/ (reemplaza las imágenes por las tuyas)
- assets/CV_Carlos_Andres_Jimenez.pdf (placeholder)

Instrucciones rápidas:
1. Reemplaza las imágenes en /assets con tus fotos y capturas.
2. Actualiza los textos (email, enlaces, descripciones).
3. Sube al repo (o reemplaza los archivos en GitHub).
4. Render hará deploy automáticamente.

Puedo subirlo por ti al repo que ya creamos si me confirmas.
